<?php if ($color): ?>
<style type='text/css'>
body.tao{ background-color:<?php print $downshift ?>;}

#page-header h2.page-title{color:<?php print $upshift ?>}

body.spaces-design #branding form input.form-text { background-color:<?php print $downshift ?>; }

body.spaces-design #branding,
body.spaces-design #navigation,
body.spaces-design #branding form input.form-text { border-color:<?php print $upshift ?>; }
</style>
<?php endif; ?>
