// initialise plugins
jQuery(function(){
	jQuery('ul.sf-menu').superfish();
});