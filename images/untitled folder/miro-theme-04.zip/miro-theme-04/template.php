<?php

function mothership_id_safe($string) { 
  // Replace with dashes anything that isn't A-Z, numbers, dashes, or underscores.
  $string = strtolower(preg_replace('/[^a-zA-Z0-9_-]+/', '-', $string));
  $string = strtolower(str_replace('_', '-', $string));   //die _ die!
   
  // If the first character is not a-z, add 'n' in front.
  if (!ctype_lower($string{0})) { // Don't use ctype_alpha since its locale aware.
    $string = 'id' . $string;
  }
  return $string;
}


function miro_menu_item_link($link) {
  if (empty($link['localized_options'])) {
    $link['localized_options'] = array();
  }

  //define a class for each tab 
  //TODO check out the multilang hell....
  $linkclass = mothership_id_safe($link['title']);
  
  // If an item is a LOCAL TASK, render it as a tab
  if($link['type'] & MENU_IS_LOCAL_TASK) {
    $link['title'] = '<span class="tab '. $linkclass .' ">' . check_plain($link['title']) . '</span>';
    $link['localized_options']['html'] = TRUE;
    $link['localized_options']['attributes'] = array('class' => $linkclass);
  }else{
    // its a standard menu item lets kick in a span class
    $link['title'] = '<span class="icon-'. $linkclass .' ">' . check_plain($link['title']) . '</span>';
    $link['localized_options']['html'] = TRUE;
    $link['localized_options']['attributes'] = array('class' => $linkclass);
  }
  
  return l($link['title'], $link['href'], $link['localized_options']);
}


/**
 * Generate a nice looking byline
 */
function miro_seed_byline($object) {
  static $accounts;
  $output = '';

  // This is a comment
  if (isset($object->cid)) {
    $date = $object->timestamp;
    $uid = !empty($object->uid) ? $object->uid : NULL;
    $name = !empty($object->name) ? $object->name : NULL;
  }
  // This is a node
  else if ($object->nid) {
    $date = $object->created;
    $uid = !empty($object->uid) ? $object->uid : NULL;
    $name = !empty($object->name) ? $object->name : NULL;
  }

  // Build output
  $date = seed_rel_date($date);
  if ($uid) {
    if (!isset($accounts[$uid])) {
      $accounts[$uid] = user_load(array('uid' => $uid));
    }
    if (!empty($accounts[$uid])) {
      $picture = theme('user_picture', $accounts[$uid]);
      $username = theme('username', $accounts[$uid]);
    }
  }
  if (empty($username)) {
    $username = theme('username', $object);
  }
  return "<div class='date'>$date</div>  $username  $picture";
}
