<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language ?>" lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">
  <head>
    <?php print $head ?>
    <?php print $styles ?>
    <title><?php print $head_title ?></title>
  </head>
  <body <?php print drupal_attributes($attr) ?>>

	<div id="container">

  <?php if ($admin) print $admin ?>

  <?php if ($messages || $console): ?>
    <div id='growl'>
      <?php print $messages; ?>
      <?php if ($logged_in && $console) print $console; ?>
    </div>
  <?php endif; ?>

  <?php if (!empty($header)): ?>
    <div id='header'><div class='limiter clear-block'>
      <?php  print $header; ?>
    </div></div>
  <?php endif; ?>

  <div id="top"><div class='limiter clear-block'>
		<div class='clear-block'>

			<?php if($user->uid >= 1){ ?>
				<div id="topnavigation">
					<div class="icon"><a href="<?php print base_path() .'home' ?>" class="home"> home</a></div>
					<div class="icon"><?php print l('user', 'user/' . $user->uid, array('attributes' => array('class' => 'user'))); ?></div>
					<div class="icon"><?php print l('logout', 'logout', array('attributes' => array('class' => 'logout'))); ?></div>
					<div class="space"><?php print $space_title ?></div>

				</div>
			<?php } ?>

			<?php if($user->uid >= 1){ ?>
			  <div id="toolbar">
			    <?php if (!empty($dropdown_links)) print $dropdown_links ?>
			    <?php // if (!empty($user_links)) print $user_links ?>	
					<div id="search">
			    	<?php if ($search_box) print $search_box ?>			
					</div>

					<?php if (in_array("admin", $user->roles)) {  ?>
						<div class="icon"><?php print l(t('admin'), 'admin', array('attributes' => array('class' => 'admin-link'))); ?></div>
					<?php } ?>

			  </div>
			<?php } ?>

			<div id="logo">
		    <?php if (!empty($spaces_logo)): ?>
					<?php print $spaces_logo ?>
		    <?php elseif ($space_title): ?>
		      <h1 class='space-title'>
						<?php  if (!empty($picture)) print $picture ?>
						<?php print $space_title ?>
					</h1>
		    <?php endif; ?>
			</div>

		</div>

		<div id="links" class="limiter clear-block">

			<!-- <div class="home">
				<?php print $space_title ?>	
			</div> -->
			

		  <?php if ($primary_links): ?>
			  <div id='navigation' class='atrium-skin limiter clear-block'>
			    <?php  if (isset($primary_links)) print theme('links', $primary_links, array('id' => 'features-menu', 'class' => 'links primary-links')) ?>
			  </div>
		  <?php endif; ?>

		  <?php if ($title || $tabs): ?>
			  <div id='page-header'  class="limiter clear-block">
			    <div class='context-links'><?php if (!empty($context_links)) print $context_links ?></div>
			    <?php if ($title): ?><h2 class='page-title'><?php print $title ?></h2><?php endif; ?>

			    <?php  if ($tabs) print $tabs ?>

			  </div>

		  <?php endif; ?>
			
		</div>

 	</div></div>


  <div id='page'><div class='limiter clear-block'>

    <?php if (isset($space_links)) print $space_links ?>

    <?php if ($tabs2) print $tabs2 ?>

    <?php if (!empty($custom_layout)): ?>
      <?php print $content ?>
    <?php else: ?>
      <?php if ($mission): ?><div class="mission"><?php print $mission ?></div><?php endif; ?>
      <div id='main' class='clear-block'>
          <div id='content' class='clear-block'><?php print $content ?></div>
      </div>
      <?php if ($right): ?>
        <div id='right' class='clear-block'><?php print $right ?></div>
      <?php endif; ?>
    <?php endif; ?>

  </div></div>

  <div id="footer"><div class='limiter clear-block'>
		<div id="footer-inner">
	    <?php if (isset($secondary_links)) : ?>
	      <?php print theme('links', $secondary_links, array('class' => 'links secondary-links')) ?>
	    <?php endif; ?>
	    <?php if (!empty($feed_icons)) print $feed_icons ?>
	    <?php if (!empty($footer)) print $footer ?>
	    <?php if (!empty($footer_message)) print $footer_message ?>
		</div>

		<div id="credits">
			<div id="logo-openatrium"><?php print t('powered by') ?><a href="http://openatrium.org">Open Atrium</a></div>
			<div id="miro-info">
					miro theme <?php print t('by') ?> <a href="http://geekroyale.com">geek Röyale</a> | 
					 <a href="http://developmentseed.com">Development seed	</a> 
			</div>
			
		</div>

  </div></div>

  <?php print $scripts ?>
  <?php print $closure ?>

		</div>
  </body>
</html>
