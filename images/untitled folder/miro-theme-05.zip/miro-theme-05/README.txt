--------------------------------------------------
	M.I.R.O  -a theme for openartrium 
--------------------------------------------------
build for the beta 2 of open atrium (http://openatrium.com)

icons are from the awesome fugue icon set: http://www.pinvoke.com

Get the source: 
svn trunk: http://geekroyale.svn.beanstalkapp.com/miro/trunk/

comments etc: morten@geekroyale.com 

more info: http://morten.dk/node/230