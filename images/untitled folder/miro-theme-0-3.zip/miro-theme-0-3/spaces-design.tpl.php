<?php if ($color): ?>
<style type='text/css'>
body.tao{ background-color:<?php print $downshift ?>;}

#page-header h2.page-title{color:<?php print $downshift ?>}

#home a{color:<?php print $color ?>}
	#home a:hover{color:<?php print $upshift ?>}

#credits{background:<?php print $downshift ?>;	border: 1px solid <?php print $color ?>; color:<?php print $upshift ?>; }
#credits a{color:<?php print $upshift ?>; }


body.spaces-design #branding form input.form-text { background-color:<?php print $downshift ?>; }

body.spaces-design #branding,
body.spaces-design #navigation,
body.spaces-design #branding form input.form-text { border-color:<?php print $upshift ?>; }
</style>
<?php endif; ?>
