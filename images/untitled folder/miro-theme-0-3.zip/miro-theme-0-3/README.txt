--------------------------------------------------
	M.I.R.O  -a theme for openartrium 
--------------------------------------------------
install into /sites/all/themes/

svn trunk:
http://geekroyale.svn.beanstalkapp.com/miro/trunk/

comments etc:
morten@geekroyale.com 

more info: http://morten.dk/node/230


